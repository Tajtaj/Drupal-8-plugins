<?php
namespace Drupal\First\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Component\Utility\SafeMarkup;
class FirstController {
	public function test(){
	$age = 34;
    return new JsonResponse(array(
      'string' => "Hello World, I am $age today.",
      'age' => $age,
    ));
	}
	
	public function test2(){
	$age = 36;
    return new JsonResponse(array(
      'string' => "Hello World, I am $age today.",
      'age' => $age,
    ));
	}
}