<?php
namespace Drupal\dataset_view;
use Drupal\dataset_view\Plugin\Field\FieldFormatter\parseCSV;
class IndexingProcesses {
  
  public static function data_indexing($output,$nid,$indexName,$indexType, &$context){
    $message = 'Indexing the data...';
    //drupal_set_message("<pre>".print_r($output,true)."</pre>");
    if($output[9] == '["success"]'){
      $results[] = 1;
      $node = \Drupal\node\Entity\Node::load($nid);
      $node->field_data_index_name->value  = $indexName;
      $node->field_data_index_type_name->value  = $indexType;
      $node->field_indexed->value  = "1";
      $node->save();
    }
    $context['message'] = $message;
    $context['results'] = $results;
  }

  function index_finished_callback($success, $results, $operations) {
    // The 'success' parameter means no fatal PHP errors were detected. All
    // other error management should be handled using 'results'.
    if ($success) {
      $message = \Drupal::translation()->formatPlural(
        count($results),
        'Data is successfully indexed.');
      $status = 'status';
    }
    else {
      $message = t('Finished with an error.');
      $status = 'error';
    }
    drupal_set_message($message, $status);
  }

  public static function delete_index($indexName){
    $drupal_root = str_replace("\\", "/", DRUPAL_ROOT);
    require_once $drupal_root . '/es_scripts/Elastica/vendor/autoload.php';
    
    $elasticaClient = new \Elastica\Client([
      'host' => 'localhost',
      'port' => 9200,
    ]);
     $cluster = $elasticaClient->getCluster();
    $existingIndexes = $cluster->getIndexNames();

    $elasticaIndex = $elasticaClient->getIndex($indexName);
     if ( in_array($indexName, $existingIndexes) )
      {
    $response = $elasticaIndex->delete();
       }
  
  
   }

}