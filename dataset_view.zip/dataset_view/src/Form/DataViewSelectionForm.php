<?php

/**
 * @file
 * Contains \Drupal\dataset_view\Form\DataViewSelectionForm.
 */

namespace Drupal\dataset_view\Form;

use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\CssCommand;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\dataset_view\Ajax\McalSegmentationCommand;
use Drupal\dataset_view\Plugin\Field\FieldFormatter\parseCSV;

/**
 * Data view field selection form.
 */
class DataViewSelectionForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'DataViewSelection_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $indexName = NULL, $index_Type = NULL) {
    $form['indexName'] = [
      '#type' => 'hidden',
      '#value' => $indexName,
      '#id' => "indexName1",
    ];
    $form['indexType'] = [
      '#type' => 'hidden',
      '#value' => $index_Type,
      '#id' => "indexType1",
    ];
     

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
  }

  /**
   * {@inheritdoc}
   */
  public function createDataView(array &$form, FormStateInterface $form_state) {
    $indexName = $form_state->getValue('indexName');
    $indexType = $form_state->getValue('indexType');
    $response = new AjaxResponse();

    $response->addCommand(new McalSegmentationCommand('dataTable'));
    $response->addCommand(new McalSegmentationCommand('setSelection', $indexName . "---" . $indexType));
    $response->addCommand(new CssCommand('#dataview_form', ["display" => "none"]));
    $response->addCommand(new CssCommand('#data_view', ["display" => "block"]));
    return $response;
  }

}
