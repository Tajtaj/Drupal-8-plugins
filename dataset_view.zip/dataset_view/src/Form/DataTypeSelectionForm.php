<?php

/**
 * @file
 * Contains \Drupal\dataset_view\Form\DataViewSelectionForm.
 */

namespace Drupal\dataset_view\Form;

use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\CssCommand;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\dataset_view\Ajax\McalSegmentationCommand;
use Drupal\dataset_view\Plugin\Field\FieldFormatter\parseCSV;

/**
 * Data view field selection form.
 */
class DataTypeSelectionForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'data_type_selection_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $allFields=array()) {
    $node = \Drupal::routeMatch()->getParameter('node');
    $nid = $node->id();
    $node_title = $node->getTitle();
    $indexName = preg_replace("/[^A-Za-z0-9 ]/", '_', $node_title);
    $indexName = str_replace(" ", "_", $indexName);
    $indexName = strtolower($indexName);
    
    $itemCounter = 1;
    $columnNameArray = array();
    foreach ($allFields as $val) {
      $valArr =  explode("=", $val);
      $columnName = $valArr[0];
      $columnName = str_replace(".", "_", $columnName);
      $columnName = str_replace(" ", "_", $columnName);
      $columnNameArray[$columnName] = $columnName;
    }
    
    
    
    foreach ($allFields as $val) {
      $valArr =  explode("=", $val);
      $columnName = $valArr[0];
      $colDataTye = $valArr[1];
      
      if($colDataTye == "character" || $colDataTye == "factor") {
        $slectedVal = $columnName.'|keyword';
      } else if($colDataTye == "integer") {
        $slectedVal = $columnName.'|integer';
      } else if($colDataTye == "numeric") {
        $slectedVal = $columnName.'|float';
      }
      $columnName = str_replace(".", "_", $columnName);
      $columnName = str_replace(" ", "_", $columnName);
      $form['select_data_type_'.$itemCounter] = [
        '#type' => 'select',
        '#title' => $this->t("Select Data Type for <i><b>'". $columnName ."'</b></i>" ),
        '#options' => [
          $columnName.'|float' => $this->t('Float'),
          $columnName.'|integer' => $this->t('Integer'),
          $columnName.'|keyword' => $this->t('Keyword'),
        ],
        '#default_value' => $slectedVal,
      ];
      $itemCounter++;
    }
   $form['indexName'] = [
      '#type' => 'hidden',
      '#value' => $indexName,
      '#id' => "indexName",
    ];
    
    $form['colCount'] = [
      '#type' => 'hidden',
      '#value' => ($itemCounter - 1),
      '#id' => "colCount",
    ];
    $form['nodeID'] = [
      '#type' => 'hidden',
      '#value' => ($nid),
      '#id' => "nodeID",
    ]; 
   $form['submit'] = [
      '#type' => 'submit',
      '#value' => t('Index Data'),
    ];
    
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $indexName = $form_state->getValue('indexName');
    $totalcolumns = $form_state->getValue('colCount');
    $nid = $form_state->getValue('nodeID');
    $datatypeArray = array();
    $keywordFields = array();
    $integerFields = array();
    $floatFields = array();
    $extraParam = array(
      "nid" => $nid,
    );
    $datatypeArray['id'] = array('type' => 'integer');
    for($i=1 ; $i <= $totalcolumns; $i++) {
      $columnVal = $form_state->getValue('select_data_type_'.$i);
      $columnNameDataType = explode("|", $columnVal);
      $columnName = $columnNameDataType[0];
      $dataType = $columnNameDataType[1];
      $datatypeArray[$columnName] = array('type' => $dataType);
      if($dataType == "keyword") {
        $keywordFields[] = $columnName;
      } else if($dataType == "integer") {
        $integerFields[] = $columnName;
      } else if($dataType == "float") {
        $floatFields[] = $columnName;
      }
    }
    $allFieldsArr = array(
      "keyword" => $keywordFields,
      "integer" => $integerFields,
      "float" => $floatFields
    );
    
    echo "<pre>";
    print_r($allFieldsArr);
    print_r($extraParam);
    print_r($datatypeArray);
    print_r($nid);
    echo $indexName;
    exit();
    $batch = array(
      'title' => t('Indexing'),
      'operations' => array(
        array('\Drupal\dataset_view\IndexingProcesses::create_n_mapping', array($indexName, $nid, $datatypeArray)),
        array('\Drupal\dataset_view\IndexingProcesses::data_indexing', array($extraParam, $allFieldsArr))
      ),
      'finished' => '\Drupal\dataset_view\IndexingProcesses::my_finished_callback',
    );
    batch_set($batch);
  }

  

}
