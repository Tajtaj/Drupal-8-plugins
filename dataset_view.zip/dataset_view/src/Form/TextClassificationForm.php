<?php

/**
 * @file
 * Contains \Drupal\dataset_view\Form\TextClassificationForm.
 */

namespace Drupal\dataset_view\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Create report form.
 */
class TextClassificationForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'text_classification_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $query = \Drupal::entityQuery('node');
    $query->condition('status', 1);
    $query->condition('type', 'classification');
    $results = $query->execute();
    $data_options = [];
    foreach ($results as $result) {
      $node = entity_load('node', $result);
      $data_options[$node->id()] = $node->getTitle();
    }

    $form['data_select'] = [
      '#type' => 'select',
      '#title' => $this->t('Select data set'),
      '#options' => $data_options,
      '#description' => t('Please select dataset.'),
      '#required' => TRUE,
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => t('Submit'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $datasetID = $form_state->getValue('data_select');
    $form_state->setRedirect('entity.node.canonical', ['node' => $datasetID]);
    return;
  }

}
