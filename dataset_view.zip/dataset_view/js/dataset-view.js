(function($, Drupal) {
 // $(document).ready(function(){
/**
  Add More functionality to add more filter fields 
**/
 $(".add-more").click(function () {
          //e.preventDefault();
          var next = $('#filter_count').val();
          next++;

          var getDomCols = $("#cols_list1").html();
          var newfilterdiv = '<div id="filter' + next + '" class="col-md-12 col-sm-12 col-xs-12 filterDiv">';
          var newSelectColList = '<div class="col-md-3 col-sm-3 col-xs-12">';
          newSelectColList += '<select class="form-select required form-control" id="cols_list' + next + '" name="cols_list' + next + '">';
          newSelectColList += getDomCols + '</select></div>';
          var getDomOp = $("#op_list1").html();

          var newSelectOpList = '<div class="col-md-3 col-sm-3 col-xs-12">';
          newSelectOpList += '<select class="form-select required form-control option-list" id="op_list' + next + '" name="op_list' + next + '">';
          newSelectOpList += getDomOp + '</select></div>';

          var newValIn = '<div class="col-md-3 col-sm-3 col-xs-12">';
          newValIn += '<input class="form-control" type="text" id="fil_val' + next + '" name="fil_val' + next + '" placeholder="Value"></div>';

          var removebtn = '<div class="col-md-3 col-sm-3 col-xs-12">';
          removebtn += '<input type="button" value="Remove" id="rmbtn_' + next + '" class="btn btn-danger remove-me" /></div>';
          var newfilterdivEnd = '</div>';

          var compDiv = newfilterdiv + newSelectColList + newSelectOpList + newValIn + removebtn + newfilterdivEnd;

          $('.filterDiv').last().after(compDiv);
          $('#filter_count').val(next);
          return false;
        });

        /**
         Remove filter field from  filter field 
        **/
       $('#newsentimentform').on('click', '.remove-me', function () {
          var rmvbtnID = $(this).attr('id');
          var splitres = rmvbtnID.split("_");
          $('#filter' + splitres[1]).remove();
          var pre = $('#filter_count').val();
          pre--;
          $('#filter_count').val(pre);
        });
       
       $('.formshow').removeClass('formhide');
      $('#new_sentiment_form').slideUp('normal');
          // setTimeout(function () { table.draw(); }, 1000);






/**
functionality to show filter model for filteration.
**/
Drupal.AjaxCommands.prototype.mcalSegmentationCommandInvoke = function (ajax, response, status) {
    if (response.fid == "dataTable") {
    }

    if (response.fid == "setSelection") {
    }

  };
Drupal.behaviors.mcalSegmentCommandBehave = {
    attach: function (context, settings) {
       $('#csv_as_dataTable th').on('click', '.filterPopup', function (e) {
        e.stopPropagation();
        var clickedTh = $(this).parent();
        selectedField = $(this).next('div').find('span').html();
        console.log("################");
        console.log(selectedField);
        console.log("###############");
        //var splitFieldName = selectedField.split(" (");
        //selectedField = splitFieldName[0];
        $('#LiveColumnFilter .modal-header h4').html(selectedField);
        $("#LiveColumnFilterOption :selected").prop('selected', false);
        //$('#LiveColumnFilterValue').val("");
        selectedField = selectedField.replace(".","_");
        selectedField = selectedField.replace(" ","_");
        selectedField = selectedField;
        $('#LiveColumnFilterFieldSelected').val(selectedField);
        if (selectedField == "comments" || selectedField == "responsive") {
          return false;
        }
        $('#LiveColumnFilter').modal('show');
       });
    }
};

  


Drupal.behaviors.mcalSegmentDataTableTrigger = {
  attach: function (context, settings) {
    $(document).ready(function () {
      $.fn.dataTable.ext.errMode = 'none'; // remove the default warning alert.
      /////////////////////////////////////////////////////////////////////////////////
      var indexName = document.getElementById("indexName").value;
      var indexType = document.getElementById("indexType").value;
      var headersData = document.getElementById('headersData').value;
      var table  =  $('#csv_as_dataTable').DataTable({
        "colReorder": {
            fixedColumnsLeft: 1,
            fixedColumnsRight: 1,
          },
        "pagingType": "full_numbers",
         "scrollX": false,
         "colReorder": true,
         "iDisplayLength": 100,
         "aLengthMenu": [[100, 200, 500, 1000], [100, 200, 500, 1000]],
         "initComplete": function(settings, json) {
          $('#csv_as_dataTable').wrap("<div id='db_scroll'></div>");
            // jquery nicescroll
            // jQuery("#db_scroll").niceScroll({
            // touchbehavior:false,
            // cursorcolor:"#005bfb",
            // zindex:100,
            // cursoropacitymax:1,
            // cursorwidth:13,
            // background:"#ebebeb",
            // autohidemode:false,
            // cursorborderradius:"0px",
            // cursorborder:"0px",
            // });
            },
          "bProcessing": true,
          "oLanguage": {
            "sProcessing": "<div class='datatableNewProcessor'>Processing..</div>"
          },
          "aaSorting": [],
          "columns": JSON.parse(headersData),
          "bFilter": false,
          "bServerSide": true,
          // "columnDefs": [{
          //   "targets": -1,
          //   "visible": false,
          // }],
         "sAjaxSource": "/es_scripts/data_table_server.php",
         "fnServerData": function (sSource, aoData, fnCallback) {
          aoData.push({"name": "indexName", "value": indexName});
          aoData.push({"name": "indexType", "value": indexType});
          //getting the values form fields 
          var filersCount = $('input[name="filter_count"]').val();
            var filterJson = "";
            for (i = 1; i <= filersCount; i++) {
              if ($('#filter' + i).length == 0) {
                continue;
              }
              if ($('#fil_val' + i).val() == "") {
                continue;
              }
              var colname = $('#cols_list' + i).val();

              var operator = $('#op_list' + i).val();
              var required_val = $('#fil_val' + i).val();
              if (colname == '' || operator == '') {
                alert('Column name & operators are required to apply filter');
                return false;
              }
              //alert(colname);
              filterJson += '{"colname":"' + colname + '", "operator":"' + operator + '", "required_val":"' + required_val + '"},';
            }
            filterJson = filterJson.replace(/,\s*$/, "");
            filterJson = "[" + filterJson + "]";
            aoData.push({"name": "filterJson", "value": filterJson});
            console.log("************filterjson**************");
            console.log(aoData);
            console.log("***************************");
          
          //@ajax call to server
            $.ajax({
              "dataType": 'json',
              "type": "GET",
              "url": sSource,
              "data": aoData,
              "success": function (json) {
                //var json = '{"iDisplaying": 3,"iTotalDisplayRecords": 3,"iTotalRecords": 3,"aaData": [["Nixon","Architect","5421"],["Nixon1","Architect1","54211"],["Nixon2","Architect","5421"]]}';
                console.log("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
                //console.log(JSON.parse(json));
                console.log(json);
                console.log("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
                //fnCallback(JSON.parse(json));
                fnCallback(json);
              },
              "timeout": 30000,   // Optional if you want to handle timeouts (which you should)
              //"error": handleAjaxError // this sets up jQuery to give me errors.
            });

      /////////////////////////////////////////////////////////////////////////////////////
      ////////////////////////////////////////////////////////////////////////////////////
     },
  });  // End of datatable 
       /////////////////////////////////////////////////////////////////////////////////  
  /***
** multiple filter functionality....
***/
   $("#Sentiment").on('click', function () {
   $('.nav-tabs a[href="#datatab"]').tab('show');
   var filterJson = "";
   var filtersCount = $('#filter_count').val();
   for (i = 1; i <= filtersCount; i++) {
              if ($('#filter' + i).length == 0) {
                continue;
              }
              if ($('#fil_val' + i).val() == "") {
                continue;
              }
              var colname = $('#cols_list' + i).val();

              var operator = $('#op_list' + i).val();
              var required_val = $('#fil_val' + i).val();
        
    filterJson += '{"colname":"' + colname + '", "operator":"' + operator + '", "required_val":"' + required_val + '"},';
            }
        table.draw();
    });//end of multi filter...     

/**
  **Bootstrap filter modal functionality
    **/////////////////////
   //$("#live_filter_submit").on('click', function (event) {
   	$('#live_filter_submit').unbind('click').bind('click', function (e){
          //console.log("Marking .....");
          var selectedField = $('#LiveColumnFilterFieldSelected').val();
          var selectedOption = $('#LiveColumnFilterOption').val();
          var selectedValue = $('#LiveColumnFilterValue').val();
          if (selectedField == '' || selectedOption == '' || selectedValue == '') {
            alert('Operator and Value required to apply filter');
            return false;
          }
          $('#LiveColumnlive_filter_submitFilter').modal('hide');
          var next = $('#filter_count').val();
           next++;
           var getDomCols = $("#cols_list1").html();
          var newfilterdiv = '<div id="filter' + next + '" class="col-md-12 col-sm-12 col-xs-12 filterDiv">';
          var newSelectColList = '<div class="col-md-3 col-sm-3 col-xs-12">';
          newSelectColList += '<select class="form-select required form-control" id="cols_list' + next + '" name="cols_list' + next + '">';
          newSelectColList += getDomCols + '</select></div>';
          var getDomOp = $("#op_list1").html();
          var newSelectOpList = '<div class="col-md-3 col-sm-3 col-xs-12">';
          newSelectOpList += '<select class="form-select required form-control option-list" id="op_list' + next + '" name="op_list' + next + '">';
          newSelectOpList += getDomOp + '</select></div>';
                    var newValIn = '<div class="col-md-3 col-sm-3 col-xs-12">';
          newValIn += '<input class="form-control" type="text" id="fil_val' + next + '" name="fil_val' + next + '" placeholder="Value"></div>';

          var removebtn = '<div class="col-md-3 col-sm-3 col-xs-12">';
          removebtn += '<input type="button" value="Remove" id="rmbtn_' + next + '" class="btn btn-danger remove-me" /></div>';
          var newfilterdivEnd = '</div>';
          var compDiv = newfilterdiv + newSelectColList + newSelectOpList + newValIn + removebtn + newfilterdivEnd;
          $('.filterDiv').last().after(compDiv);
          $('#filter_count').val(next);

           var i =  $('#cols_list' + next).val(selectedField);
          $("#op_list" + next).val(selectedOption);

           if (selectedValue.indexOf(',') > -1) {
            var newValArray = selectedValue.trim();
            newValArray = newValArray.split(",");
            $("#fil_val" + next).attr("data-slider-min", "0");
            $("#fil_val" + next).attr("data-slider-max", "100");
            $("#fil_val" + next).attr("data-slider-value", "[" + newValArray[0] + ", " + newValArray[1] + "]");
            $("#fil_val" + next).slider({});
            $("#fil_val" + next).before('<b id="min_range_txt_' + next + '" style="float: left; margin-right: 15px;">0</b>');
            $("#fil_val" + next).after('<b id="max_range_txt_' + next + '" style="margin-left: 15px;">100</b>');
          }
          else {
            $('#fil_val' + next).val(selectedValue);
          }
          $('#LiveColumnFilter').modal('hide');
          table.draw();
          return false;
               
        });
//////////////////////////////////////////////////////////////
        

      });//end document ready
    }
  
  };

  
 // }); // Document ready ...
})(jQuery,Drupal);  

