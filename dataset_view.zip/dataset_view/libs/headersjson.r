args <- commandArgs(trailingOnly = TRUE)

library(jsonlite)
library(base64enc)
library(elastic)
library(elasticsearchr)

json <- rawToChar(base64decode(args))
argoptions <- fromJSON(json)
indexName <- argoptions$indexName
indexType <- argoptions$indexType
# jsPath <- argoptions$jsonFilePath

# indexName <- "small_dataset1_ac_beta2_12163"
# indexType <- "small_dataset1_ac_beta2_type"
# jsPath <- "/var/www/actuarial-beta3.xululabs.us/htdocs/modules/mcal_text_segmentation/headerjson/test.json"

invisible(connect())
map.body <- Search(indexName,indexType, size = 1)
headings <- attributes(map.body$hits$hits[[1]]$`_source`)
jsArray<-toJSON(headings$names)
print(jsArray)
#smapJson<-toJSON(map)
#print(map.body[[indexName]]$mappings[[indexType]])
# for(i in  attributes(map.body[[indexName]]$mappings[[indexType]]$properties)) {
#   headings <- attributes(map.body[[indexName]]$mappings[[indexType]]$properties[i])
#   jsArray<-toJSON(headings$names)
#   print(jsArray)
  
# }
