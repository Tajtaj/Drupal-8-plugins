args <- commandArgs(trailingOnly = TRUE)

library(jsonlite)
library(base64enc)
library(elasticsearchr)
library(elastic)

json <- rawToChar(base64decode(args))
argoptions <- fromJSON(json)
dataset1 <- argoptions$dataset
indexName1 <- argoptions$indexName
indexType1 <- argoptions$indexType


actualData <- read.csv(dataset1)
col.name <- gsub("[[:space:]]", "_", actualData)

col.types <- lapply(actualData,class)
col.name <- colnames(actualData)

col.name <- gsub("[[:space:]]", "_", col.name)
col.name <- gsub("\\.", "_",col.name)

mapping_custom <- function(mappingData) {
  jsonlite::prettify(mappingData)
}
names(actualData)  <- col.name
map.body <- list(mappings = list(type = list(properties= list())),settings = list(index=list(max_result_window=1000000)))

for(i in  seq_along(col.types)) {
  
  if (col.types[i] == 'integer')
  {
    map.body$mappings$type$properties[[col.name[i]]] <- list(type="integer")
    
  }else{
    map.body$mappings$type$properties[[col.name[i]]]  <- list(type="keyword")
  }
  
}
# Check if index exits, if not then create it with the specified mapping;
connect()
if(index_exists(indexName1)){
  random <- round(runif(1,10000,20000))
  indexName1 <- paste(indexName1,random,sep = "_")
  
  elastic("http://localhost:9200", indexName1,indexType1) %create% mapping_custom(toJSON(map.body,auto_unbox = TRUE))
  connect()
  invisible(docs_bulk(actualData,index = indexName1, type = indexType1,raw = FALSE, chunk_size = 100000))
  print(toJSON("success"))
  print(toJSON(list("indexName"= indexName1,"indexType"=indexType1)))
 
  
}else{
  elastic("http://localhost:9200", indexName1,indexType1) %create% mapping_custom(toJSON(map.body,auto_unbox = TRUE))
  connect()	
  invisible(docs_bulk(actualData,index = indexName1, type = indexType1,raw = FALSE, chunk_size = 100000))
  print(toJSON("success"))
  print(toJSON(list("indexName"= indexName1,"indexType"=indexType1)))
}

