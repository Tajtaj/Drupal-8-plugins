<?php
/**
 * @file
 * Contains \Drupal\article\Plugin\Block\XaiBlock.
 */

namespace Drupal\customblock\Plugin\Block;

use Drupal\Core\Block\BlockBase;


/**
 * Provides a 'article' block.
 *
 * @Block(
 *   id = "custom_block-poweredby",
 *   admin_label = @Translation("Custom block poweredby"),
 *   category = @Translation("Custom block poweredby")
 * )
 */
class CustomBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
  	//$html = '';
  	//$date = date("Y");
    //$html = '<p>Copyright '.$date.' . All rights reserved</p>';
    //$output[] = ['#markup' => $html];
    //return $output;
    $form = \Drupal::formBuilder()->getForm('\Drupal\drupalup_simple_form\Form\SimpleAjaxForm');
    return $form;
  }
}
